###Title: eCardly
###Type: lab/hw
###Time Require: 2/3hrs

###Prerequisites
- HTML
- CSS

###Objectives: What student should be able to do by end
Build eCardly from spec


###Original Source Attribution
n/a

###Additional Resources
[css floats 101](http://alistapart.com/article/css-floats-101)

###Post-mortem:
  - What worked
  - Student misunderstandings

###How to run this activity